
<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="assets/font/googleSourceSans.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="template/plugins/fontawesome-free/css/all.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="template/dist/css/adminlte.min.css">
<link rel="stylesheet" href="assets/css/nav.css">
<!-- Toastr -->
<link rel="stylesheet" href="template/plugins/toastr/toastr.min.css">
<!-- Main CSS -->
<link rel="stylesheet" href="assets/css/main.css">