<!-- jQuery -->
<script src="template/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="template/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="template/dist/js/adminlte.min.js"></script>

<script src="assets/js/nav.js"></script>

<!-- Toastr -->
<script src="template/plugins/toastr/toastr.min.js"></script>